import { useEffect, useState, type KeyboardEvent } from 'react';
import { supabase } from '../lib/supabaseClient';
import type { FormEvent } from 'react';
import { todayLocalISO } from '../utils/date';

type Job = {
  id: number;
  name: string;
};

type Vendor = {
  id: number;
  nick_name: string;
};

type Installer = {
  id: number;
  first_name: string;
  last_name: string | null;
};

type Account = {
  id: number;
  name: string;
  code: string | null;
  account_types: { name: string } | null;
  purpose_default: 'business' | 'personal' | 'mixed' | null;
};

type MortgagePreview = {
  dealNickname: string;
  total: number;
  principal: number;
  interest: number;
  escrow: number;
};


type RealEstateDeal = {
  id: number;
  nickname: string;
  address: string | null;
  type: string | null;
  status: string | null;
  loan_account_id: number | null;
};

type TxType = 'income' | 'expense';
type ExpenseKind = 'material' | 'labor' | 'other';

type NewTransactionFormProps = {
  initialJobId?: number | null;
  onTransactionSaved?: () => void;
};

// ----------------- CHART-OF-ACCOUNTS HELPERS -----------------

// Convert account.code (string like "1000" or "61000") to a number
function codeToNumber(code: string | null): number | null {
  if (!code) return null;
  const n = Number(code.replace(/\D/g, ''));
  return Number.isFinite(n) ? n : null;
}

// Define which code ranges represent *cash-like* accounts
//   1000–1999 → bank / checking / savings
//   2000–2200 → corp & personal credit cards + Mom Debt (once recoded to 2200)
const CASH_CODE_RANGES: Array<[number, number]> = [
  [1000, 1999],
  [2000, 2200],
];

function isCodeInRanges(code: string | null, ranges: Array<[number, number]>): boolean {
  const n = codeToNumber(code);
  if (n == null) return false;
  return ranges.some(([min, max]) => n >= min && n <= max);
}

// -------------------------------------------------------------

export function NewTransactionForm({
  initialJobId,
  onTransactionSaved,
}: NewTransactionFormProps) {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [installers, setInstallers] = useState<Installer[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [realEstateDeals, setRealEstateDeals] = useState<RealEstateDeal[]>([]);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  // form state
  const [linkToJob, setLinkToJob] = useState<boolean>(!!initialJobId);
  const [jobId, setJobId] = useState<string>(initialJobId != null ? String(initialJobId) : '');
  const [linkToDeal, setLinkToDeal] = useState<boolean>(false);
  const [dealId, setDealId] = useState<string>('');

  const [date, setDate] = useState<string>(() => todayLocalISO());

  const [txType, setTxType] = useState<TxType>('expense');
  const [expenseKind, setExpenseKind] = useState<ExpenseKind>('material');

  const [vendorId, setVendorId] = useState<string>('');
  const [installerId, setInstallerId] = useState<string>('');

  const [cashAccountId, setCashAccountId] = useState<string>('');
  const [categoryAccountId, setCategoryAccountId] = useState<string>('');

  const [description, setDescription] = useState<string>('');
  const [amount, setAmount] = useState<string>('');

  const [isCleared, setIsCleared] = useState<boolean>(false);

  // Mortgage-specific state
  const [isMortgagePayment, setIsMortgagePayment] = useState<boolean>(false);
  const [mortgageInterest, setMortgageInterest] = useState<string>('');
  const [mortgageEscrow, setMortgageEscrow] = useState<string>('');
  const [mortgagePreview, setMortgagePreview] = useState<MortgagePreview | null>(null);
  const [showMortgageModal, setShowMortgageModal] = useState(false);


  useEffect(() => {
    async function loadOptions() {
      setLoading(true);
      setError(null);
      try {
        // Jobs (only open, newest first)
        const { data: jobsData, error: jobsErr } = await supabase
          .from('jobs')
          .select('id, name, status, start_date');

        if (jobsErr) throw jobsErr;

        const openJobs = (jobsData ?? []).filter((j) => j.status !== 'closed');

        const sortedOpenJobs = openJobs.sort((a, b) => {
          const da = a.start_date ? new Date(a.start_date).getTime() : 0;
          const db = b.start_date ? new Date(b.start_date).getTime() : 0;
          return db - da;
        });

        setJobs(sortedOpenJobs);

        // Vendors
        const { data: vendorsData, error: vendorsErr } = await supabase
          .from('vendors')
          .select('id, nick_name')
          .order('nick_name', { ascending: true });
        if (vendorsErr) throw vendorsErr;
        setVendors((vendorsData ?? []) as Vendor[]);

        // Installers
        const { data: installersData, error: installersErr } = await supabase
          .from('installers')
          .select('id, first_name, last_name')
          .order('first_name', { ascending: true });
        if (installersErr) throw installersErr;
        setInstallers((installersData ?? []) as Installer[]);

        // Accounts
        const { data: accountsData, error: accountsErr } = await supabase
          .from('accounts')
          .select('id, name, code, purpose_default, account_types(name)');

        if (accountsErr) throw accountsErr;

        const normalizedAccounts: Account[] = (accountsData ?? []).map(
          (a: any) => ({
            id: a.id,
            name: a.name,
            code: a.code ?? null,
            account_types: a.account_types ?? null,
            purpose_default: (a.purpose_default ?? null) as Account['purpose_default'],
          })
        );

        // Custom sort: account_id = 1 first, 4 second, then by ID number
        const sortedAccounts = normalizedAccounts.sort((a, b) => {
          const priorityA =
            a.id === 1
              ? 0
              : a.id === 4
              ? 1
              : 2;

          const priorityB =
            b.id === 1
              ? 0
              : b.id === 4
              ? 1
              : 2;

          if (priorityA !== priorityB) {
            return priorityA - priorityB;
          }

          return a.id - b.id;
        });

        setAccounts(sortedAccounts);

        // Real estate deals (include loan_account_id for principal booking)
        const { data: dealsData, error: dealsErr } = await supabase
          .from('real_estate_deals')
          .select('id, nickname, address, type, status, loan_account_id')
          .order('id', { ascending: true });

        if (dealsErr) throw dealsErr;

        setRealEstateDeals((dealsData ?? []) as RealEstateDeal[]);
      } catch (err: any) {
        console.error(err);
        setError(err.message ?? 'Error loading options');
      } finally {
        setLoading(false);
      }
    }

    void loadOptions();
  }, []);

  useEffect(() => {
    if (initialJobId != null) {
      setLinkToJob(true);
      setJobId(String(initialJobId));
    }
  }, [initialJobId]);

  // ---------- CASH & CATEGORY SELECTION USING CODE RANGES ----------

  // 1) Cash-like accounts: only those in CASH_CODE_RANGES and of type asset/liability
  const cashAccounts = accounts.filter((a) => {
    const type = a.account_types?.name;
    const isBalSheet = type === 'asset' || type === 'liability';
    if (!isBalSheet) return false;
    return isCodeInRanges(a.code, CASH_CODE_RANGES);
  });

  // 2) Basic P&L sets
  const incomeAccounts = accounts.filter(
    (a) => a.account_types?.name === 'income'
  );
  const expenseAccounts = accounts.filter(
    (a) => a.account_types?.name === 'expense'
  );

  // 3) Non-cash balance sheet accounts (asset / liability / equity, but *not* in cashAccounts)
  const balanceSheetNonCash = accounts.filter((a) => {
    const type = a.account_types?.name;
    if (!type) return false;

    const isBS =
      type === 'asset' || type === 'liability' || type === 'equity';

    if (!isBS) return false;

    const isCash = cashAccounts.some((c) => c.id === a.id);
    return !isCash;
  });

  // 4) Final category set:
  //    - For Income transactions: only income accounts
  //    - For Expense transactions: expenses + non-cash balance sheet accounts
  const categoryAccounts =
    txType === 'income'
      ? incomeAccounts
      : [...expenseAccounts, ...balanceSheetNonCash];

  const [categoryTypeahead, setCategoryTypeahead] = useState('');
  const [lastCategoryTypeTime, setLastCategoryTypeTime] = useState<number>(0);

  const sortedCategoryAccounts = [...categoryAccounts].sort((a, b) => {
    const purposeRank = (p: Account['purpose_default'] | null | undefined) => {
      if (p === 'business') return 0;
      if (p === 'personal') return 1;
      return 2; // mixed/unknown/undefined
    };

    const rankA = purposeRank(a.purpose_default);
    const rankB = purposeRank(b.purpose_default);

    if (rankA !== rankB) return rankA - rankB;

    const nameA = a.name.toLowerCase();
    const nameB = b.name.toLowerCase();
    return nameA.localeCompare(nameB);
  });

  // -----------------------------------------------------------------

  function handleCategoryKeyDown(e: KeyboardEvent<HTMLSelectElement>) {
    const key = e.key;

    // Ignore navigation / modifier keys
    if (
      key.length !== 1 ||
      e.altKey ||
      e.metaKey ||
      e.ctrlKey
    ) {
      return;
    }

    e.preventDefault();

    const now = Date.now();
    const resetWindowMs = 800;

    let buffer =
      now - lastCategoryTypeTime > resetWindowMs
        ? key
        : categoryTypeahead + key;

    buffer = buffer.toLowerCase();

    setCategoryTypeahead(buffer);
    setLastCategoryTypeTime(now);

    const currentIndex = sortedCategoryAccounts.findIndex(
      (a) => String(a.id) === categoryAccountId
    );

    const startIndex = currentIndex >= 0 ? currentIndex + 1 : 0;

    const ordered = [
      ...sortedCategoryAccounts.slice(startIndex),
      ...sortedCategoryAccounts.slice(0, startIndex),
    ];

    const match = ordered.find((a) => {
      const label = `${a.code ? `${a.code} – ` : ''}${a.name}`.toLowerCase();
      return label.includes(buffer);
    });

    if (match) {
      setCategoryAccountId(String(match.id));
    }
  }

  function formatInstaller(i: Installer) {
    return `${i.first_name} ${i.last_name ?? ''}`.trim();
  }

  function purposeForAccount(accountId: number): 'business' | 'personal' | 'mixed' {
    const acc = accounts.find((a) => a.id === accountId);
    const def = acc?.purpose_default;

    if (def === 'personal') return 'personal';
    if (def === 'mixed') return 'mixed';

    return 'business';
  }

  const effectiveExpenseKind: ExpenseKind =
    linkToJob && txType === 'expense' ? expenseKind : 'other';

  // Check if date is more than 7 days in future
  const isDateFuture = (() => {
    if (!date) return false;
    const selectedDate = new Date(date + 'T00:00:00');
    const sevenDaysFromNow = new Date();
    sevenDaysFromNow.setDate(sevenDaysFromNow.getDate() + 7);
    return selectedDate > sevenDaysFromNow;
  })();

  // Check if amount is large
  const amtNum = Number(amount) || 0;
  const isAmountLarge = amtNum > 10000;

  // Mortgage principal preview (not persisted directly)
  const interestNum = Number(mortgageInterest) || 0;
  const escrowNum = Number(mortgageEscrow) || 0;
  const computedPrincipal = Math.max(amtNum - interestNum - escrowNum, 0);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    const amt = Number(amount);

    // === BASIC VALIDATION (blocking) ===
    if (linkToJob && !jobId) {
      setError('Job is required when linking this transaction to a job.');
      return;
    }
    if (linkToDeal && !dealId) {
      setError('Deal is required when linking this transaction to a real estate deal.');
      return;
    }
    if (!cashAccountId) {
      setError('Pay from / deposit to account is required.');
      return;
    }
    if (!amount || !amt || amt <= 0) {
      setError('Amount must be greater than 0.');
      return;
    }

    // Only enforce vendor/installer when needed
    if (txType === 'expense' && linkToJob && !isMortgagePayment) {
      if (effectiveExpenseKind === 'material' && !vendorId) {
        setError('Vendor is required for material job expense.');
        return;
      }
      if (effectiveExpenseKind === 'labor' && !installerId) {
        setError('Installer is required for labor job expense.');
        return;
      }
    }

    // === MORTGAGE-SPECIFIC VALIDATION ===
    const mortgageMode = isMortgagePayment && linkToDeal && !!dealId && txType === 'expense';

    if (mortgageMode) {
      if (!mortgageInterest && !mortgageEscrow) {
        setError('For a mortgage payment, enter at least interest or escrow.');
        return;
      }
      if (computedPrincipal < 0) {
        setError(
          'Interest + escrow is greater than the total amount. Principal would be negative.'
        );
        return;
      }
    }

    // === ENHANCED VALIDATION (warnings) ===

    // Warning 1: Large amount (possible typo)
    if (amt > 10000) {
      const confirm = window.confirm(
        `⚠️ Large Amount Warning\n\n` +
          `You entered: ${amt.toLocaleString('en-US', {
            style: 'currency',
            currency: 'USD',
          })}\n\n` +
          `This is unusually large. Did you mean to enter this amount?\n\n` +
          `Common mistake: $100,000 instead of $1,000.00\n\n` +
          `Click OK to proceed, or Cancel to fix it.`
      );
      if (!confirm) return;
    }

    // Warning 2: Future date (more than 7 days ahead)
    const selectedDate = new Date(date + 'T00:00:00');
    const today = new Date();
    const sevenDaysFromNow = new Date(today);
    sevenDaysFromNow.setDate(today.getDate() + 7);

    if (selectedDate > sevenDaysFromNow) {
      const confirm = window.confirm(
        `⚠️ Future Date Warning\n\n` +
          `The date you selected is more than a week in the future.\n\n` +
          `Selected: ${selectedDate.toLocaleDateString()}\n` +
          `Today: ${today.toLocaleDateString()}\n\n` +
          `Is this correct?\n\n` +
          `Click OK to proceed, or Cancel to fix it.`
      );
      if (!confirm) return;
    }

    // Warning 3: Check for potential duplicate transactions (only for normal expenses)
    if (!mortgageMode && txType === 'expense' && vendorId && description) {
      try {
        const threeDaysAgo = new Date(selectedDate);
        threeDaysAgo.setDate(selectedDate.getDate() - 3);
        const threeDaysForward = new Date(selectedDate);
        threeDaysForward.setDate(selectedDate.getDate() + 3);

        const { data: recentLines, error: dupErr } = await supabase
          .from('transaction_lines')
          .select('id, amount, transactions(date, description)')
          .eq('vendor_id', Number(vendorId))
          .gte('transactions.date', threeDaysAgo.toISOString().split('T')[0])
          .lte('transactions.date', threeDaysForward.toISOString().split('T')[0])
          .limit(10);

        if (!dupErr && recentLines && recentLines.length > 0) {
          const possibleDuplicate = recentLines.find((line: any) => {
            const lineAmt = Math.abs(Number(line.amount));
            const amtMatch = Math.abs(lineAmt - amt) < 1; // Within $1
            const descMatch =
              line.transactions?.description
                ?.toLowerCase()
                .includes(description.toLowerCase());
            return amtMatch || descMatch;
          });

          if (possibleDuplicate) {
            const dupDate = (possibleDuplicate as any).transactions?.date;
            const dupAmt = Math.abs(Number((possibleDuplicate as any).amount));
            const dupDesc = (possibleDuplicate as any).transactions
              ?.description;

            const confirm = window.confirm(
              `⚠️ Possible Duplicate Transaction\n\n` +
                `Found a similar transaction:\n` +
                `Date: ${dupDate}\n` +
                `Amount: ${dupAmt.toLocaleString('en-US', {
                  style: 'currency',
                  currency: 'USD',
                })}\n` +
                `Description: ${dupDesc}\n\n` +
                `Are you sure you want to create another transaction?\n\n` +
                `Click OK to proceed, or Cancel to review.`
            );
            if (!confirm) return;
          }
        }
      } catch (err) {
        console.warn('Duplicate check failed:', err);
      }
    }

    // === PROCEED WITH SAVE ===
    setSaving(true);
    try {
      const job_id = linkToJob && jobId ? Number(jobId) : null;
      const real_estate_deal_id =
        linkToDeal && dealId ? Number(dealId) : null;

      const cash_id = Number(cashAccountId);

      // --- derive a single transaction-level purpose ---
      const cashPurposeDefault = purposeForAccount(cash_id);
      // For normal (non-mortgage) path we still need category account id early:
      const category_id = categoryAccountId ? Number(categoryAccountId) : null;
      const categoryPurposeDefault = category_id
        ? purposeForAccount(category_id)
        : 'business';

      let txPurpose: 'business' | 'personal' =
        cashPurposeDefault === 'personal' ||
        categoryPurposeDefault === 'personal'
          ? 'personal'
          : 'business';

      const cashPurpose = txPurpose;
      const categoryPurpose = txPurpose;
      // ---------------------------------------------------

      // ---------- MORTGAGE PAYMENT FLOW ----------
      if (mortgageMode) {
        const selectedDeal = realEstateDeals.find(
          (d) => d.id === Number(dealId)
        );
        if (!selectedDeal) {
          setError('Selected real estate deal not found.');
          setSaving(false);
          return;
        }

        if (!selectedDeal.loan_account_id) {
          setError(
            'This real estate deal does not have a loan account linked (loan_account_id is null).'
          );
          setSaving(false);
          return;
        }

        const interestAccount = accounts.find(
          (a) => a.name === 'RE – Mortgage Interest'
        );
        const escrowAccount = accounts.find(
          (a) => a.name === 'RE – Taxes & Insurance'
        );

        if (!interestAccount || !escrowAccount) {
          setError(
            'Could not find RE – Mortgage Interest and/or RE – Taxes & Insurance accounts.'
          );
          setSaving(false);
          return;
        }

        const totalPayment = Number(amount) || 0;
        const interestPortion = interestNum;
        const escrowPortion = escrowNum;
        const principal = computedPrincipal;

        if (totalPayment <= 0) {
          setError('Total mortgage payment must be greater than zero.');
          setSaving(false);
          return;
        }

        setMortgagePreview({
          dealNickname: selectedDeal.nickname,
          total: totalPayment,
          principal,
          interest: interestPortion,
          escrow: escrowPortion,
        });

        setShowMortgageModal(true);
        setSaving(false);
        return;
      }


      // ---------- NORMAL (NON-MORTGAGE) FLOW ----------
      if (!categoryAccountId) {
        setError('Category account is required.');
        setSaving(false);
        return;
      }

      const category_id_normal = Number(categoryAccountId);

      const vendor_id =
        txType === 'expense' &&
        linkToJob &&
        effectiveExpenseKind === 'material'
          ? vendorId
            ? Number(vendorId)
            : null
          : null;

      const installer_id =
        txType === 'expense' &&
        linkToJob &&
        effectiveExpenseKind === 'labor'
          ? installerId
            ? Number(installerId)
            : null
          : null;

      // Recompute purpose with the actual category used
      const categoryPurposeDefaultNormal = purposeForAccount(category_id_normal);

      txPurpose =
        cashPurposeDefault === 'personal' ||
        categoryPurposeDefaultNormal === 'personal'
          ? 'personal'
          : 'business';

      const cashPurposeNormal = txPurpose;
      const categoryPurposeNormal = txPurpose;

      let line1: any;
      let line2: any;

      if (txType === 'income') {
        line1 = {
          account_id: cash_id,
          amount: amt,
          job_id,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: cashPurposeNormal,
          is_cleared: isCleared,
        };

        line2 = {
          account_id: category_id_normal,
          amount: -amt,
          job_id,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: categoryPurposeNormal,
          is_cleared: isCleared,
        };
      } else {
        // expense
        line1 = {
          account_id: category_id_normal,
          amount: amt,
          job_id,
          vendor_id,
          installer_id,
          real_estate_deal_id,
          purpose: categoryPurposeNormal,
          is_cleared: isCleared,
        };

        line2 = {
          account_id: cash_id,
          amount: -amt,
          job_id,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: cashPurposeNormal,
          is_cleared: isCleared,
        };
      }

      const { data, error: rpcErr } = await supabase.rpc(
        'create_transaction',
        {
          p_date: date,
          p_description: description || null,
          p_line1: line1,
          p_line2: line2,
          p_purpose: txPurpose,
        }
      );

      if (rpcErr) throw rpcErr;

      console.log('Transaction created:', data);

      setSuccess('Transaction saved.');
      setAmount('');
      setDescription('');
      setVendorId('');
      setInstallerId('');
      setIsCleared(false);
      // keep job/deal linkage as-is so you can input multiple related lines quickly

      if (onTransactionSaved) {
        onTransactionSaved();
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message ?? 'Error saving transaction');
    } finally {
      setSaving(false);
    }
  }

  async function handleConfirmMortgageSplit() {
    if (!mortgagePreview) return;

    try {
      setSaving(true);
      setError(null);
      setSuccess(null);

      const real_estate_deal_id =
        linkToDeal && dealId ? Number(dealId) : null;

      if (!real_estate_deal_id) {
        setError('Real estate deal is required for mortgage payments.');
        setSaving(false);
        return;
      }

      const selectedDeal = realEstateDeals.find(
        (d) => d.id === real_estate_deal_id
      );

      if (!selectedDeal) {
        setError('Selected real estate deal not found.');
        setSaving(false);
        return;
      }

      if (!selectedDeal.loan_account_id) {
        setError(
          'This real estate deal does not have a loan account linked (loan_account_id is null).'
        );
        setSaving(false);
        return;
      }

      const interestAccount = accounts.find(
        (a) => a.name === 'RE – Mortgage Interest'
      );
      const escrowAccount = accounts.find(
        (a) => a.name === 'RE – Taxes & Insurance'
      );

      if (!interestAccount || !escrowAccount) {
        setError(
          'Could not find RE – Mortgage Interest and/or RE – Taxes & Insurance accounts.'
        );
        setSaving(false);
        return;
      }

      const cash_id = Number(cashAccountId);
      if (!cash_id) {
        setError('Cash/bank account is required.');
        setSaving(false);
        return;
      }

      // Recompute purpose exactly like in handleSubmit
      const cashPurposeDefault = purposeForAccount(cash_id);
      const category_id = categoryAccountId ? Number(categoryAccountId) : null;
      const categoryPurposeDefault = category_id
        ? purposeForAccount(category_id)
        : 'business';

      let txPurpose: 'business' | 'personal' =
        cashPurposeDefault === 'personal' ||
        categoryPurposeDefault === 'personal'
          ? 'personal'
          : 'business';

      const cashPurpose = txPurpose;

      const {
        principal,
        interest: interestPortion,
        escrow: escrowPortion,
      } = mortgagePreview;

      // 1) Interest transaction: DR interest expense, CR cash
      if (interestPortion > 0) {
        const line1 = {
          account_id: interestAccount.id,
          amount: interestPortion,
          job_id: null,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: txPurpose,
          is_cleared: isCleared,
        };

        const line2 = {
          account_id: cash_id,
          amount: -interestPortion,
          job_id: null,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: cashPurpose,
          is_cleared: isCleared,
        };

        const { error: rpcErr1 } = await supabase.rpc('create_transaction', {
          p_date: date,
          p_description:
            description || `Mortgage interest – ${selectedDeal.nickname}`,
          p_line1: line1,
          p_line2: line2,
          p_purpose: txPurpose,
        });

        if (rpcErr1) throw rpcErr1;
      }

      // 2) Escrow transaction: DR escrow asset, CR cash
      if (escrowPortion > 0) {
        const line1 = {
          account_id: escrowAccount.id,
          amount: escrowPortion,
          job_id: null,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: txPurpose,
          is_cleared: isCleared,
        };

        const line2 = {
          account_id: cash_id,
          amount: -escrowPortion,
          job_id: null,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: cashPurpose,
          is_cleared: isCleared,
        };

        const { error: rpcErr2 } = await supabase.rpc('create_transaction', {
          p_date: date,
          p_description:
            description || `Mortgage escrow – ${selectedDeal.nickname}`,
          p_line1: line1,
          p_line2: line2,
          p_purpose: txPurpose,
        });

        if (rpcErr2) throw rpcErr2;
      }

      // 3) Principal transaction: DR loan liability (reduces it), CR cash
      if (principal > 0) {
        const line1 = {
          account_id: selectedDeal.loan_account_id,
          amount: principal,
          job_id: null,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: txPurpose,
          is_cleared: isCleared,
        };

        const line2 = {
          account_id: cash_id,
          amount: -principal,
          job_id: null,
          vendor_id: null,
          installer_id: null,
          real_estate_deal_id,
          purpose: cashPurpose,
          is_cleared: isCleared,
        };

        const { error: rpcErr3 } = await supabase.rpc('create_transaction', {
          p_date: date,
          p_description:
            description || `Mortgage principal – ${selectedDeal.nickname}`,
          p_line1: line1,
          p_line2: line2,
          p_purpose: txPurpose,
        });

        if (rpcErr3) throw rpcErr3;
      }

      setSuccess('Mortgage payment split saved.');
      setAmount('');
      setMortgageInterest('');
      setMortgageEscrow('');
      // keep job/deal linkage & isMortgagePayment so you can enter multiple similar payments quickly

      if (onTransactionSaved) {
        onTransactionSaved();
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message ?? 'Failed to save mortgage payment.');
    } finally {
      setSaving(false);
      setShowMortgageModal(false);
      setMortgagePreview(null);
    }
  }

function handleCancelMortgageSplit() {
  setShowMortgageModal(false);
  setMortgagePreview(null);
}


  if (loading) {
    return <p>Loading options…</p>;
  }

  return (
    <div>
      <h2>New Transaction</h2>

      {error && (
        <p style={{ color: 'red', marginTop: '0.5rem' }}>{error}</p>
      )}
      {success && (
        <p style={{ color: 'green', marginTop: '0.5rem' }}>{success}</p>
      )}

      <form
        onSubmit={handleSubmit}
        style={{ maxWidth: 520, display: 'grid', gap: '0.75rem' }}
      >
        {/* Job linkage */}
        <label
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
        >
          <input
            type="checkbox"
            checked={linkToJob}
            onChange={(e) => setLinkToJob(e.target.checked)}
          />
          Relates to a job?
        </label>

        {linkToJob && (
          <label>
            Job
            <select
              value={jobId}
              onChange={(e) => setJobId(e.target.value)}
            >
              <option value="">Select job…</option>
              {jobs.map((j) => (
                <option key={j.id} value={j.id}>
                  {j.name}
                </option>
              ))}
            </select>
          </label>
        )}

        {/* Real estate deal linkage */}
        <label
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
        >
          <input
            type="checkbox"
            checked={linkToDeal}
            onChange={(e) => {
              const checked = e.target.checked;
              setLinkToDeal(checked);
              if (!checked) {
                setDealId('');
                setIsMortgagePayment(false);
                setMortgageInterest('');
                setMortgageEscrow('');
              }
            }}
          />
          Relates to a real estate deal?
        </label>

        {linkToDeal && (
          <label>
            Real estate deal
            <select
              value={dealId}
              onChange={(e) => setDealId(e.target.value)}
            >
              <option value="">Select deal…</option>
              {realEstateDeals.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.nickname}
                  {d.address ? ` – ${d.address}` : ''}
                </option>
              ))}
            </select>
          </label>
        )}

        {/* Mortgage payment toggle & panel (only when linked to a deal and expense) */}
        {linkToDeal && txType === 'expense' && (
          <label
            style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
          >
            <input
              type="checkbox"
              checked={isMortgagePayment}
              onChange={(e) => {
                const checked = e.target.checked;
                setIsMortgagePayment(checked);
                if (!checked) {
                  setMortgageInterest('');
                  setMortgageEscrow('');
                }
              }}
              disabled={!dealId}
            />
            This is a mortgage payment (PITI split)
          </label>
        )}

        {linkToDeal && txType === 'expense' && isMortgagePayment && (
          <div
            className="card"
            style={{
              padding: '0.75rem',
              border: '1px solid #ddd',
              borderRadius: 8,
              background: '#fafafa',
            }}
          >
            <div style={{ fontSize: 13, marginBottom: '0.5rem' }}>
              Enter the interest and escrow amounts from your mortgage
              statement. Principal will be calculated as:
              <br />
              <code>principal = total amount − interest − escrow</code>
            </div>

            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
                gap: '0.5rem',
              }}
            >
              <label>
                Interest portion
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={mortgageInterest}
                  onChange={(e) => setMortgageInterest(e.target.value)}
                />
              </label>
              <label>
                Escrow
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  value={mortgageEscrow}
                  onChange={(e) => setMortgageEscrow(e.target.value)}
                />
              </label>
              <label>
                Principal (computed)
                <input
                  type="text"
                  readOnly
                  value={
                    computedPrincipal > 0
                      ? computedPrincipal.toFixed(2)
                      : '0.00'
                  }
                  style={{ background: '#eee' }}
                />
              </label>
            </div>
          </div>
        )}

        <label>
          Date
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            max={new Date(
              new Date().setFullYear(new Date().getFullYear() + 1)
            )
              .toISOString()
              .split('T')[0]}
            min="2000-01-01"
            style={{
              borderColor: isDateFuture ? '#ff9800' : undefined,
              borderWidth: isDateFuture ? '2px' : undefined,
            }}
          />
          {isDateFuture && (
            <span
              style={{
                fontSize: 12,
                color: '#ff9800',
                marginTop: '4px',
                display: 'block',
              }}
            >
              ⚠️ This date is in the future. Is this correct?
            </span>
          )}
        </label>

        <label>
          Type
          <select
            value={txType}
            onChange={(e) => {
              const val = e.target.value as TxType;
              setTxType(val);
              // Turning into income should disable mortgage mode
              if (val === 'income') {
                setIsMortgagePayment(false);
                setMortgageInterest('');
                setMortgageEscrow('');
              }
            }}
          >
            <option value="expense">Expense</option>
            <option value="income">Income</option>
          </select>
        </label>

        {txType === 'expense' && linkToJob && !isMortgagePayment && (
          <label>
            Expense kind
            <select
              value={expenseKind}
              onChange={(e) =>
                setExpenseKind(e.target.value as ExpenseKind)
              }
            >
              <option value="material">Material</option>
              <option value="labor">Labor</option>
              <option value="other">Other</option>
            </select>
          </label>
        )}

        {txType === 'expense' &&
          linkToJob &&
          effectiveExpenseKind === 'material' &&
          !isMortgagePayment && (
            <label>
              Vendor
              <select
                value={vendorId}
                onChange={(e) => setVendorId(e.target.value)}
              >
                <option value="">Select vendor…</option>
                {vendors.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.nick_name}
                  </option>
                ))}
              </select>
            </label>
          )}

        {txType === 'expense' &&
          linkToJob &&
          effectiveExpenseKind === 'labor' &&
          !isMortgagePayment && (
            <label>
              Installer
              <select
                value={installerId}
                onChange={(e) => setInstallerId(e.target.value)}
              >
                <option value="">Select installer…</option>
                {installers.map((i) => (
                  <option key={i.id} value={i.id}>
                    {formatInstaller(i)}
                  </option>
                ))}
              </select>
            </label>
          )}

        <label>
          Pay from / deposit to (bank or card)
          <select
            value={cashAccountId}
            onChange={(e) => setCashAccountId(e.target.value)}
          >
            <option value="">Select account…</option>
            {cashAccounts.map((a) => {
              const isCard = a.account_types?.name === 'liability';
              const label = `${a.code ? `${a.code} – ` : ''}${a.name}${
                isCard ? ' (card)' : ''
              }`;
              return (
                <option key={a.id} value={a.id}>
                  {label}
                </option>
              );
            })}
          </select>
        </label>

        {/* Category only matters for non-mortgage flow; for mortgage we split ourselves */}
        {!isMortgagePayment && (
          <label>
            Category ({txType === 'income' ? 'income account' : 'expense/BS account'})
            <select
              value={categoryAccountId}
              onChange={(e) => setCategoryAccountId(e.target.value)}
              onKeyDown={handleCategoryKeyDown}
            >
              <option value="">Select category…</option>
              {sortedCategoryAccounts.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.code ? `${a.code} – ` : ''}
                  {a.name}
                </option>
              ))}
            </select>
          </label>
        )}

        <label>
          Description
          <input
            type="text"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="e.g. HD materials, Mortgage PITI, GL Insurance…"
          />
        </label>

        <label>
          Amount
          <input
            type="number"
            step="0.01"
            min="0"
            max="9999999"
            value={amount}
            onChange={(e) => {
              setAmount(e.target.value);
              const val = Number(e.target.value);
              if (val > 0 && error?.includes('Amount')) {
                setError(null);
              }
            }}
            style={{
              borderColor: isAmountLarge ? '#ff9800' : undefined,
              borderWidth: isAmountLarge ? '2px' : undefined,
            }}
          />
          {isAmountLarge && (
            <span
              style={{
                fontSize: 12,
                color: '#ff9800',
                marginTop: '4px',
                display: 'block',
              }}
            >
              ⚠️ This is a large amount. Double-check before saving.
            </span>
          )}
        </label>

        <label
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}
        >
          <input
            type="checkbox"
            checked={isCleared}
            onChange={(e) => setIsCleared(e.target.checked)}
          />
          Cleared already?
        </label>

        <button type="submit" disabled={saving}>
          {saving ? 'Saving…' : 'Save Transaction'}
        </button>
      </form>
      {showMortgageModal && mortgagePreview && (
      <div
        className="modal-backdrop"
        style={{
          position: 'fixed',
          inset: 0,
          backgroundColor: 'rgba(0,0,0,0.4)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000,
        }}
      >
        <div
          className="modal"
          style={{
            backgroundColor: 'white',
            padding: '1.5rem',
            borderRadius: '0.5rem',
            maxWidth: '420px',
            width: '100%',
            boxShadow: '0 10px 30px rgba(0,0,0,0.25)',
          }}
        >
          <h2 style={{ marginTop: 0, marginBottom: '0.75rem' }}>
            Mortgage Payment Split
          </h2>
          <p style={{ margin: 0, marginBottom: '0.5rem' }}>
            <strong>Deal:</strong> {mortgagePreview.dealNickname}
          </p>
          <p style={{ margin: 0, marginBottom: '0.5rem' }}>
            <strong>Total payment:</strong> ${mortgagePreview.total.toFixed(2)}
          </p>

          <table style={{ width: '100%', marginTop: '0.75rem', marginBottom: '0.75rem', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                <th style={{ textAlign: 'left', paddingBottom: '0.25rem' }}>Component</th>
                <th style={{ textAlign: 'right', paddingBottom: '0.25rem' }}>Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Interest</td>
                <td style={{ textAlign: 'right' }}>
                  ${mortgagePreview.interest.toFixed(2)}
                </td>
              </tr>
              <tr>
                <td>Escrow (taxes + insurance)</td>
                <td style={{ textAlign: 'right' }}>
                  ${mortgagePreview.escrow.toFixed(2)}
                </td>
              </tr>
              <tr>
                <td>Principal</td>
                <td style={{ textAlign: 'right' }}>
                  ${mortgagePreview.principal.toFixed(2)}
                </td>
              </tr>
            </tbody>
          </table>

          <p style={{ fontSize: '0.85rem', marginBottom: '0.75rem' }}>
            This will create three separate double-entry transactions:
            interest expense, escrow asset, and loan principal, all paid
            from the selected cash account.
          </p>

          <div
            style={{
              display: 'flex',
              justifyContent: 'flex-end',
              gap: '0.5rem',
              marginTop: '0.5rem',
            }}
          >
            <button
              type="button"
              onClick={handleCancelMortgageSplit}
              disabled={saving}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleConfirmMortgageSplit}
              disabled={saving}
            >
              {saving ? 'Saving…' : 'Confirm & Save'}
            </button>
          </div>
        </div>
      </div>
    )}

    </div>
  );
}
