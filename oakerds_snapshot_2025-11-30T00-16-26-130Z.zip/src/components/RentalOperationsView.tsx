import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';
import { formatLocalDate } from '../utils/date';

// ─────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────

type RealEstateDeal = {
  id: number;
  type: 'rental' | 'flip' | 'wholesale';
  nickname: string;
  address: string;
  status: string;
  purchase_price: number | null;
  arv: number | null;
  rental_monthly_rent: number | null;
  rental_monthly_mortgage: number | null;
  rental_monthly_taxes: number | null;
  rental_monthly_insurance: number | null;
  rental_monthly_hoa: number | null;
  interest_rate: number | null;
  loan_term_months: number | null;
  original_loan_amount: number | null;
  close_date: string | null;
  asset_account_id: number | null;
  loan_account_id: number | null;
};

type PropertyTransaction = {
  id: number;
  date: string;
  description: string;
  accountName: string;
  amount: number;
};

type PropertyData = {
  deal: RealEstateDeal;
  ytdIncome: number;
  ytdMortgageInterest: number;
  ytdTaxesInsurance: number;
  ytdRepairs: number;
  ytdOtherExpenses: number;
  ytdNetProfit: number;
  principalPaidYtd: number;
  transactions: PropertyTransaction[];
};

type TransactionLine = {
  id: number;
  amount: number;
  real_estate_deal_id: number;
  accounts: {
    id: number;
    name: string;
    account_types: { name: string } | null;
  } | null;
  transactions: {
    date: string;
    description: string | null;
  } | null;
};

// ─────────────────────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────────────────────

export function RentalOperationsView() {
  const [properties, setProperties] = useState<PropertyData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [expandedProperties, setExpandedProperties] = useState<Record<number, boolean>>({});

  const currentYear = new Date().getFullYear();

  useEffect(() => {
    loadRentalData();
  }, []);

  async function loadRentalData() {
    setLoading(true);
    setError(null);

    try {
      // 1. Load all rental deals
      const { data: dealsData, error: dealsErr } = await supabase
        .from('real_estate_deals')
        .select('*')
        .eq('type', 'rental')
        .order('nickname', { ascending: true });

      if (dealsErr) throw dealsErr;

      const deals = (dealsData ?? []) as RealEstateDeal[];

      if (deals.length === 0) {
        setProperties([]);
        setLoading(false);
        return;
      }

      // 2. Load all transaction_lines linked to these deals for current year
      const dealIds = deals.map((d) => d.id);
      const startDate = `${currentYear}-01-01`;
      const endDate = `${currentYear}-12-31`;

      const { data: linesData, error: linesErr } = await supabase
        .from('transaction_lines')
        .select(
          `
          id,
          amount,
          real_estate_deal_id,
          accounts!inner (
            id,
            name,
            account_types (name)
          ),
          transactions!inner (
            date,
            description
          )
        `
        )
        .in('real_estate_deal_id', dealIds)
        .gte('transactions.date', startDate)
        .lte('transactions.date', endDate);

      if (linesErr) throw linesErr;

      const lines = (linesData ?? []) as unknown as TransactionLine[];

      // 3. Build property data for each deal
      const propertyDataList: PropertyData[] = deals.map((deal) => {
        const dealLines = lines.filter((l) => l.real_estate_deal_id === deal.id);

        let ytdIncome = 0;
        let ytdMortgageInterest = 0;
        let ytdTaxesInsurance = 0;
        let ytdRepairs = 0;
        let ytdOtherExpenses = 0;
        let principalPaidYtd = 0;
        const transactions: PropertyTransaction[] = [];

        for (const line of dealLines) {
          const accountName = line.accounts?.name ?? '';
          const accountType = line.accounts?.account_types?.name ?? '';
          const amount = Number(line.amount) || 0;
          const absAmount = Math.abs(amount);

          // Skip cash/bank side of transactions (we only want the categorized side)
          if (accountType === 'asset' && line.accounts?.id !== deal.asset_account_id) {
            continue;
          }

          // Categorize by account
          if (accountType === 'income') {
            ytdIncome += absAmount;
            transactions.push({
              id: line.id,
              date: line.transactions?.date ?? '',
              description: line.transactions?.description ?? '',
              accountName: 'Rental Income',
              amount: absAmount,
            });
          } else if (accountType === 'liability' && line.accounts?.id === deal.loan_account_id) {
            // Principal payment (reduces loan liability)
            principalPaidYtd += absAmount;
            transactions.push({
              id: line.id,
              date: line.transactions?.date ?? '',
              description: line.transactions?.description ?? '',
              accountName: 'Principal',
              amount: -absAmount,
            });
          } else if (accountType === 'expense') {
            if (accountName.includes('Mortgage Interest')) {
              ytdMortgageInterest += absAmount;
              transactions.push({
                id: line.id,
                date: line.transactions?.date ?? '',
                description: line.transactions?.description ?? '',
                accountName: 'Mortgage Interest',
                amount: -absAmount,
              });
            } else if (accountName.includes('Taxes') || accountName.includes('Insurance')) {
              ytdTaxesInsurance += absAmount;
              transactions.push({
                id: line.id,
                date: line.transactions?.date ?? '',
                description: line.transactions?.description ?? '',
                accountName: 'Taxes & Insurance',
                amount: -absAmount,
              });
            } else if (accountName.includes('Repairs') || accountName.includes('Maintenance')) {
              ytdRepairs += absAmount;
              transactions.push({
                id: line.id,
                date: line.transactions?.date ?? '',
                description: line.transactions?.description ?? '',
                accountName: 'Repairs',
                amount: -absAmount,
              });
            } else {
              ytdOtherExpenses += absAmount;
              transactions.push({
                id: line.id,
                date: line.transactions?.date ?? '',
                description: line.transactions?.description ?? '',
                accountName: accountName.replace(/^RE [–-] /, ''),
                amount: -absAmount,
              });
            }
          }
        }

        const ytdNetProfit =
          ytdIncome - ytdMortgageInterest - ytdTaxesInsurance - ytdRepairs - ytdOtherExpenses;

        // Sort transactions by date descending
        transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        return {
          deal,
          ytdIncome,
          ytdMortgageInterest,
          ytdTaxesInsurance,
          ytdRepairs,
          ytdOtherExpenses,
          ytdNetProfit,
          principalPaidYtd,
          transactions,
        };
      });

      setProperties(propertyDataList);
      setLoading(false);
    } catch (err: any) {
      console.error(err);
      setError(err.message ?? 'Failed to load rental data');
      setLoading(false);
    }
  }

  function handleToggleProperty(dealId: number) {
    setExpandedProperties((prev) => ({
      ...prev,
      [dealId]: !prev[dealId],
    }));
  }

  const currency = (value: number) =>
    value.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
    });

  if (loading) return <p>Loading rental data…</p>;
  if (error) return <p style={{ color: 'red' }}>Error: {error}</p>;

  const propertyCount = properties.length;

  // Portfolio totals
  const today = new Date();
  const monthsElapsed = today.getMonth() + 1;

  const portfolioYtdIncome = properties.reduce((sum, p) => sum + p.ytdIncome, 0);
  const portfolioYtdExpenses = properties.reduce(
    (sum, p) => sum + p.ytdMortgageInterest + p.ytdTaxesInsurance + p.ytdRepairs + p.ytdOtherExpenses,
    0
  );
  const portfolioYtdNet = properties.reduce((sum, p) => sum + p.ytdNetProfit, 0);
  const portfolioMonthlyNet = monthsElapsed > 0 ? portfolioYtdNet / monthsElapsed : 0;
  const portfolioPrincipalPaid = properties.reduce((sum, p) => sum + p.principalPaidYtd, 0);

  return (
    <div>
      <h2>Rental Operations</h2>

      {propertyCount === 0 && (
        <div className="card">
          <p style={{ fontSize: 14, color: '#777' }}>
            No rental properties found. Add a rental deal in the Real Estate Deals section.
          </p>
        </div>
      )}

      {propertyCount > 0 && (
        <>
          {/* Portfolio Summary */}
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))',
              gap: '1rem',
              marginBottom: '1.5rem',
            }}
          >
            <SummaryCard label="Properties" value={propertyCount} isCount />
            <SummaryCard label="YTD Income" value={portfolioYtdIncome} />
            <SummaryCard label="YTD Expenses" value={portfolioYtdExpenses} />
            <SummaryCard
              label="YTD Cash Flow"
              value={portfolioYtdNet}
              highlight={portfolioYtdNet >= 0 ? 'positive' : 'negative'}
            />
            <SummaryCard label="Avg Monthly Cash Flow" value={portfolioMonthlyNet} />
            <SummaryCard label="YTD Principal Paid" value={portfolioPrincipalPaid} />
          </div>

          {/* Property Cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {properties.map((property) => {
              const { deal } = property;
              const isExpanded = expandedProperties[deal.id] ?? false;
              const marginPct =
                property.ytdIncome > 0
                  ? (property.ytdNetProfit / property.ytdIncome) * 100
                  : 0;

              const monthlyAvgIncome = monthsElapsed > 0 ? property.ytdIncome / monthsElapsed : 0;
              const monthlyAvgExpenses =
                monthsElapsed > 0
                  ? (property.ytdMortgageInterest +
                      property.ytdTaxesInsurance +
                      property.ytdRepairs +
                      property.ytdOtherExpenses) /
                    monthsElapsed
                  : 0;
              const monthlyAvgNet = monthsElapsed > 0 ? property.ytdNetProfit / monthsElapsed : 0;

              return (
                <div
                  key={deal.id}
                  onClick={() => handleToggleProperty(deal.id)}
                  style={{
                    borderRadius: 12,
                    border: '1px solid #eee',
                    padding: '1rem 1.25rem',
                    boxShadow: '0 1px 3px rgba(0,0,0,0.05)',
                    background: '#fff',
                    cursor: 'pointer',
                  }}
                >
                  {/* Property Header */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <h3 style={{ marginTop: 0, marginBottom: '0.25rem' }}>{deal.nickname}</h3>
                      <p style={{ margin: 0, fontSize: 13, color: '#666' }}>{deal.address}</p>
                    </div>
                    <span
                      style={{
                        fontSize: 12,
                        padding: '2px 8px',
                        borderRadius: 4,
                        background: deal.status === 'stabilized' ? '#e8f5e9' : '#fff3e0',
                        color: deal.status === 'stabilized' ? '#2e7d32' : '#ef6c00',
                      }}
                    >
                      {deal.status}
                    </span>
                  </div>

                  {/* Monthly Averages Row */}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '1rem',
                      fontSize: 13,
                      color: '#555',
                      marginTop: '0.75rem',
                      marginBottom: '0.75rem',
                      flexWrap: 'wrap',
                    }}
                  >
                    <span>
                      <strong>Avg Income:</strong> {currency(monthlyAvgIncome)}/mo
                    </span>
                    <span>
                      <strong>Avg Expenses:</strong> {currency(monthlyAvgExpenses)}/mo
                    </span>
                    <span
                      style={{
                        color: monthlyAvgNet >= 0 ? '#0a7a3c' : '#b00020',
                        fontWeight: 600,
                      }}
                    >
                      <strong>Avg Net:</strong> {currency(monthlyAvgNet)}/mo
                    </span>
                  </div>

                  {/* YTD Stats */}
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))',
                      gap: '0.75rem',
                      fontSize: 14,
                      marginBottom: '0.75rem',
                    }}
                  >
                    <Stat label="YTD Income" value={property.ytdIncome} money />
                    <Stat label="YTD Interest" value={property.ytdMortgageInterest} money />
                    <Stat label="YTD Tax/Ins" value={property.ytdTaxesInsurance} money />
                    <Stat label="YTD Repairs" value={property.ytdRepairs} money />
                    <Stat label="YTD Other" value={property.ytdOtherExpenses} money />
                    <Stat
                      label="YTD Cash Flow"
                      value={property.ytdNetProfit}
                      money
                      highlight={property.ytdNetProfit >= 0 ? 'positive' : 'negative'}
                    />
                    <Stat label="YTD Principal" value={property.principalPaidYtd} money />
                    <Stat label="Margin" value={marginPct} suffix="%" />
                  </div>

                  {/* Deal Info (when expanded) */}
                  {isExpanded && (
                    <>
                      {/* Loan Details */}
                      {deal.original_loan_amount && (
                        <div
                          style={{
                            marginTop: '1rem',
                            padding: '0.75rem',
                            background: '#f9f9f9',
                            borderRadius: 8,
                            fontSize: 13,
                          }}
                        >
                          <strong>Loan Details:</strong>
                          <div
                            style={{
                              display: 'grid',
                              gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))',
                              gap: '0.5rem',
                              marginTop: '0.5rem',
                            }}
                          >
                            <span>Purchase: {currency(deal.purchase_price ?? 0)}</span>
                            <span>Loan: {currency(deal.original_loan_amount)}</span>
                            <span>Rate: {deal.interest_rate ?? 0}%</span>
                            <span>Term: {deal.loan_term_months ?? 0} months</span>
                            {deal.close_date && <span>Closed: {deal.close_date}</span>}
                          </div>
                        </div>
                      )}

                      {/* Transactions Table */}
                      <h4
                        style={{
                          marginTop: '1rem',
                          borderTop: '1px solid #eee',
                          paddingTop: '0.75rem',
                          display: 'flex',
                          alignItems: 'center',
                          gap: '0.4rem',
                          fontSize: 15,
                        }}
                      >
                        <span>▼</span> Transactions ({property.transactions.length})
                      </h4>

                      {property.transactions.length === 0 ? (
                        <p style={{ fontSize: 13, color: '#777' }}>No transactions this year.</p>
                      ) : (
                        <table
                          style={{
                            width: '100%',
                            borderCollapse: 'collapse',
                            fontSize: 13,
                            marginTop: '0.5rem',
                          }}
                        >
                          <thead>
                            <tr style={{ borderBottom: '1px solid #ddd', textAlign: 'left' }}>
                              <th style={{ padding: '0.4rem 0.5rem' }}>Date</th>
                              <th style={{ padding: '0.4rem 0.5rem' }}>Description</th>
                              <th style={{ padding: '0.4rem 0.5rem' }}>Category</th>
                              <th style={{ padding: '0.4rem 0.5rem', textAlign: 'right' }}>Amount</th>
                            </tr>
                          </thead>
                          <tbody>
                            {property.transactions.map((tx) => (
                              <tr key={tx.id} style={{ borderBottom: '1px solid #eee' }}>
                                <td style={{ padding: '0.4rem 0.5rem' }}>{formatLocalDate(tx.date)}</td>
                                <td style={{ padding: '0.4rem 0.5rem' }}>{tx.description}</td>
                                <td style={{ padding: '0.4rem 0.5rem' }}>{tx.accountName}</td>
                                <td
                                  style={{
                                    padding: '0.4rem 0.5rem',
                                    textAlign: 'right',
                                    color: tx.amount >= 0 ? '#0a7a3c' : '#b00020',
                                  }}
                                >
                                  {currency(tx.amount)}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      )}
                    </>
                  )}

                  {/* Expand hint */}
                  {!isExpanded && (
                    <p style={{ fontSize: 12, color: '#999', marginTop: '0.5rem', marginBottom: 0 }}>
                      Click to expand transactions & loan details
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Helper Components
// ─────────────────────────────────────────────────────────────

function SummaryCard({
  label,
  value,
  highlight,
  isCount,
}: {
  label: string;
  value: number;
  highlight?: 'positive' | 'negative';
  isCount?: boolean;
}) {
  const formatted = isCount
    ? value.toString()
    : value.toLocaleString('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
      });

  let color = '#333';
  if (highlight === 'positive') color = '#0a7a3c';
  if (highlight === 'negative') color = '#b00020';

  return (
    <div
      style={{
        background: '#fff',
        borderRadius: 10,
        padding: '1rem',
        boxShadow: '0 1px 3px rgba(0,0,0,0.08)',
        border: '1px solid #eee',
      }}
    >
      <div style={{ fontSize: 12, color: '#777', marginBottom: 4 }}>{label}</div>
      <div style={{ fontSize: 20, fontWeight: 600, color }}>{formatted}</div>
    </div>
  );
}

function Stat({
  label,
  value,
  money,
  suffix,
  highlight,
}: {
  label: string;
  value: number;
  money?: boolean;
  suffix?: string;
  highlight?: 'positive' | 'negative';
}) {
  let formatted: string;
  if (money) {
    formatted = value.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
  } else if (suffix) {
    formatted = value.toFixed(1) + suffix;
  } else {
    formatted = value.toLocaleString();
  }

  let color = '#333';
  if (highlight === 'positive') color = '#0a7a3c';
  if (highlight === 'negative') color = '#b00020';

  return (
    <div>
      <div style={{ fontSize: 11, color: '#777' }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 500, color }}>{formatted}</div>
    </div>
  );
}